package com.spring.Annotations;

public interface Mobileprocesser {
	
	void process();

}

package com.spring.Annotations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Realme {
	
	@Autowired
	Mobileprocesser cpu;

	public Mobileprocesser getCpu() {
		return cpu;
	}

	public void setCpu(Mobileprocesser cpu) {
		this.cpu = cpu;
	}

	public void config() {
		System.out.println("8 GB Ram and octa core");
		cpu.process();
	}

}

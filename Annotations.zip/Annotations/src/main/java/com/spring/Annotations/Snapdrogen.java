package com.spring.Annotations;

import org.springframework.stereotype.Component;

@Component
public class Snapdrogen implements Mobileprocesser {

	public void process() {
		System.out.println("world best cpu");
	}

}

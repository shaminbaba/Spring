package com.spring.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmployeeController {
	
	
	@RequestMapping("/")
	public String main() {
		
		return "index";
	}

	
	@RequestMapping("/data")
	public ModelAndView data(@RequestParam("name") String name) {
		
		ModelAndView mv=new ModelAndView();
		System.out.println(name);
		mv.addObject("result",name);
		mv.setViewName("index");
		return mv;
	} 
}

package com.Spring.core;

public class Bike implements Vehicle{
	
	
	public void drive() {
		System.out.println("I am ridding bike");
	}

}

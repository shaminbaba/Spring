package com.Spring.core;



public interface Vehicle {

	
	void drive();
	

}

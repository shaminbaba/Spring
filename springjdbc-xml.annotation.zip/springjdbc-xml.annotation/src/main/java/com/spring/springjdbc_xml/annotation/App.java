package com.spring.springjdbc_xml.annotation;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.springjdbc_xml.annotation.dao.EmployeeDao;

/**
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext context =new ClassPathXmlApplicationContext("beans.xml");
       System.out.println("started context");
       EmployeeDao employeedao = (EmployeeDao) context.getBean("employeeDao");
       
       Employee employee=new Employee();
       employee.setId(1);
       employee.setName("shamin");
       employee.setAddress("hyd");
       
      // employeedao.insert(employee);
     //  employeedao.update(2, "samba", "orangal");
     // employeedao.delete(1);
       
       List<Employee> employeelist=employeedao.select();
       employee.printdata(employeelist);
       
    }
}

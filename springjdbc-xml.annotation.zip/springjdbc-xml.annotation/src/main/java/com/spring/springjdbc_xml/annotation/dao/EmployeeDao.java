package com.spring.springjdbc_xml.annotation.dao;

import java.util.List;

import com.spring.springjdbc_xml.annotation.Employee;

public interface EmployeeDao {
	
	
	void insert(Employee employee);
	
	void delete(int id);
	
	void update(int id,String name,String address);
	List<Employee> select();
		


}

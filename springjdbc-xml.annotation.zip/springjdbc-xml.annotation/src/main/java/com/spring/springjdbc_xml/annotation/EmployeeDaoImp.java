package com.spring.springjdbc_xml.annotation;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;


import com.spring.springjdbc_xml.annotation.dao.EmployeeDao;
import com.spring.springjdbc_xml.annotation.rowmapper.Employeerowmapper;


public class EmployeeDaoImp implements EmployeeDao{

	JdbcTemplate jdbctemplate;
	


	public void setJdbctemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate = jdbctemplate;
	}


	public void insert(Employee employee) {
		
		
		String sql ="insert into Employee value(?,?,?)";
		
		Object[] obj= {employee.getId(),employee.getName(),employee.getAddress()};
		
		int no=jdbctemplate.update(sql,obj);
		System.out.println("no of inserted rows="+no);
		
		
	}


	public void delete(int id) {
	
		
		String deletesql="delete from employee where id=?";
	int no=	jdbctemplate.update(deletesql,id);
	System.out.println("no of dewleted rows="+no);
	
		
	}


	public void update(int id, String name, String address) {
		
		
		String updatesql="update employee set name="+"'"+name+"'"+",address="+"'"+address+"'"+" where id=? ";
		
		int no=jdbctemplate.update(updatesql,id);
		System.out.println("no of upadted rows"+no);
	}


	public List<Employee> select() {
		
		
		String selectsql="select * from employee";
		
List<Employee> employeedata=jdbctemplate.query(selectsql, new Employeerowmapper());
		
		
		return employeedata;
	}


	


	
}
